package org.chnu.romantoarabic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RomanToArabicApplication {

    public static void main(String[] args) {
        SpringApplication.run(RomanToArabicApplication.class, args);
    }

}
