package com.example.lab4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
